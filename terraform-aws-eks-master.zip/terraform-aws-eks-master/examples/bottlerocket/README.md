# AWS Bottlerocket based nodes

This is a minimalistic example that shows how to use functionality of this module to deploy
nodes based on [AWS Bottlerocket container OS](https://github.com/bottlerocket-os/bottlerocket)

Example is minimalistic by purpose - it shows what knobs to turn to make Bottlerocket work.
Do not use default VPC for your workloads deployment.